﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.UserStuff
{
    public class Key
    {
        //public static int K = Convert.ToInt32("This is the key to add a new user");
        public static int K = 1111111111;
        
    }
}
