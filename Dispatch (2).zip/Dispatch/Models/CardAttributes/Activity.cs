﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models.Classes;
using Models.Sections;

namespace Models.CardAttributes
{
    public class Activity
    {
        private int TripCard_ID;
        private Asset Activity_Asset;
        private Worker Activity_Line_Worker;
        private Demand Activity_Line;

        //constructor... HAS TO HAVE AN ID!
        public Activity(int id, Asset addAsset, Worker addWorker, Demand addDemand)
        {
            this.TripCard_ID = id;
            this.Activity_Asset = addAsset;
            this.Activity_Line_Worker = addWorker;
            this.Activity_Line = addDemand;
        }

    }
}
