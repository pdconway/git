﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models.Card;
using Models.Classes;
using Data_.Classes;
using Models.Sections;
using System.Collections.ObjectModel;

namespace Dispatch.Transfer
{
    public class DataTransfer
    {
        private string name = "";
        private static List<Asset> assetList;
        private static List<Worker> workerList;
        private static ObservableCollection<TripCard> tripCardList;
        private static List<TripCard> newTripCardsList;
        //the services class seems pointless but whatever........
        private static Services services = new Services();
        private static Model model;

        public DataTransfer()
        {
            model = services.RetrieveData();
            assetList = model.getAssetList();
            workerList = model.getWorkerList();
            tripCardList = model.getTripCardList();
            newTripCardsList = model.getNewTripCards();
        }
        public DataTransfer(string na)
        {
            this.name = na;
            model = services.RetrieveData();
            assetList = model.getAssetList();
            workerList = model.getWorkerList();
            tripCardList = model.getTripCardList();
            newTripCardsList = model.getNewTripCards();
        }


        public static List<Asset> AssetList
        {
            get
            {
                return assetList;
            }
        }
        public static List<Worker> WorkerList
        {
            get
            {
                return workerList;
            }
        }
        public static ObservableCollection<TripCard> TripCardList
        {
            get
            {
                return tripCardList;
            }
        }

        public static void makeTripCardListNull()
        {
            tripCardList = null;
        }
        public static void setTripCardList(ObservableCollection<TripCard> makeDataStaySame)
        {
            tripCardList = makeDataStaySame;
        }





        public static void useSampleData()
        {
            //instantiate Assets


            //add Assets to the assetList


            //instantiate Workers


            //add Workers to the workerList


            //instantiate TripCards that are "already made"


            TripCard zero = new TripCard();
            TripCard one = new TripCard();
            TripCard two = new TripCard();
            TripCard three = new TripCard();


            //add TripCards to the tripCardList


            tripCardList.Add(zero);
            tripCardList.Add(one);
            tripCardList.Add(two);
            tripCardList.Add(three);


            //instantiate TripCards that are orders


            //add TripCards to the newTripCardsList

        }

    }
}
